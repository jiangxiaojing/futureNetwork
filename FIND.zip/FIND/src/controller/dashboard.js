/**

 @Name：layuiAdmin Echarts集成
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：GPL-2
    
 */


layui.define(function(exports) {



    //区块轮播切换
    layui.use(['admin', 'carousel'], function() {
        var $ = layui.$,
            admin = layui.admin,
            carousel = layui.carousel,
            element = layui.element,
            device = layui.device();

        //轮播切换
        $('.layadmin-carousel').each(function() {
            var othis = $(this);
            carousel.render({
                elem: this,
                width: '100%',
                arrow: 'none',
                interval: othis.data('interval'),
                autoplay: othis.data('autoplay') === true,
                trigger: (device.ios || device.android) ? 'click' : 'hover',
                anim: othis.data('anim')
            });
        });

    });

    function getNowTime(sec) {
        var timestamp = Date.parse(new Date());
        var date = new Date(timestamp - sec * 1000);
        let hour = date.getHours();
        let minute = date.getMinutes();
        let second = date.getSeconds();
        return hour + ":" + minute + ":" + second;
    }


    //柱状图（改动）
    layui.use(['echarts'], function() {
        var nowTimeArray = [getNowTime(0), getNowTime(5), getNowTime(10), getNowTime(15), getNowTime(20), getNowTime(30)]
        var $ = layui.$,
            echarts = layui.echarts;

        //产线开功率
        var echnormcol = [],
            normcol = [{
                dataZoom: {
                    show: 'true',
                    start: 0,
                    end: 100
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function(params) {
                        return params[0].name + '<br>' +
                            '预期开功率： ' + params[1].data + '%<br>' +
                            '实际开功率： ' + params[0].data + '%<br>';

                    }
                },
                legend: {
                    data: ['产线开功率', '预期开功率']
                },
                calculable: true,
                xAxis: [{
                    name: '日期',
                    type: 'category',
                    data: ['10/8', '10/9', '10/10', '10/11', '10/12', '10/13', '10/14', '10/15', '10/16', '10/17', '10/18', '10/19', '10/20', '10/21', '10/22', '10/23', '10/24', '10/25', '10/25', '10/27', '10/28', '10/29', '10/30', '10/31', '11/1', '11/2', '11/3', '11/4', '11/5', '11/6']
                }],
                yAxis: [{
                    name: '开功率（%）',
                    type: 'value'
                }],
                series: [{
                        name: '产线开功率',
                        type: 'line',
                        data: [12, 14, 15, 18, 23, 29, 25, 32, 33, 38, 37, 40, 41, 42, 45, 50, 52, 53, 54, 63, 62, 63, 68, 61, 75, 78, 81, 84, 87],
                        markPoint: {
                            data: [
                                { type: 'max', name: '月最大' },
                                { type: 'min', name: '月最小' }
                            ]
                        }
                    },
                    {
                        name: '预期开功率',
                        type: 'line',
                        data: [15, 16, 18, 22, 25, 28, 31, 35, 38, 41, 45, 50, 51, 54, 58, 63, 65, 67, 69, 70, 72, 75, 79, 81, 85, 86, 88, 90, 91]
                    }
                ]
            }],
            elemNormcol = $('#LAY-index-normcol').children('div'),
            renderNormcol = function(index) {
                echnormcol[index] = echarts.init(elemNormcol[index], layui.echartsTheme);
                echnormcol[index].setOption(normcol[index]);
                window.onresize = echnormcol[index].resize;
            };
        if (!elemNormcol[0]) return;
        renderNormcol(0);



        //产线停产率
        var echnormbar = [],
            normbar = [{
                dataZoom: {
                    show: 'true',
                    start: 0,
                    end: 100
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function(params) {
                        return params[0].name + '<br>' +
                            '预期停工率： ' + params[1].data + '%<br>' +
                            '实际停工率： ' + params[0].data + '%<br>' +
                            '<b>停工原因</b><br>' +
                            '供应商占比： 20%<br>' +
                            '加工商占比： 30%<br>' +
                            '通信占比： 50%<br>';

                    }
                },
                legend: {
                    data: ['产线停工率', '预期停工率']
                },
                calculable: true,
                xAxis: [{
                    name: '日期',
                    type: 'category',
                    data: ['10/8', '10/9', '10/10', '10/11', '10/12', '10/13', '10/14', '10/15', '10/16', '10/17', '10/18', '10/19', '10/20', '10/21', '10/22', '10/23', '10/24', '10/25', '10/25', '10/27', '10/28', '10/29', '10/30', '10/31', '11/1', '11/2', '11/3', '11/4', '11/5', '11/6']
                }],
                yAxis: [{
                    name: '停工率（%）',
                    type: 'value'
                }],
                series: [{
                        name: '产线停工率',
                        type: 'line',
                        data: [23, 10, 12, 12, 14, 22, 24, 14, 16, 13, 9, 12, 16, 5, 15, 22, 13, 13, 14, 13, 8, 13, 10, 11, 12, 14, 9, 11, 7],
                        markPoint: {
                            data: [
                                { type: 'max', name: '月最大' },
                                { type: 'min', name: '月最小' }
                            ]
                        }
                    },
                    {
                        name: '预期停工率',
                        type: 'line',
                        data: [20, 14, 10, 12, 13, 12, 4, 10, 10, 6, 11, 12, 6, 14, 6, 13, 13, 8, 13, 10, 12, 7, 8, 11, 10, 11, 8, 4, 7]
                    }
                ]
            }],
            elemNormbar = $('#LAY-index-normbar').children('div'),
            renderNormbar = function(index) {
                echnormbar[index] = echarts.init(elemNormbar[index], layui.echartsTheme);
                echnormbar[index].setOption(normbar[index]);
                window.onresize = echnormbar[index].resize;
            };
        if (!elemNormbar[0]) return;
        renderNormbar(0);

        //焊接电流
        var ecurrentbar = [];
        var currentbar = [{
                dataZoom: {
                    show: false,
                    start: 0,
                    end: 100
                },
                grid: {
                    x: '15%',
                    x2: '10%'
                },
                tooltip: {
                    trigger: 'axis',
                },
                legend: {
                    data: ['KPL1', 'KPL2', 'KPL3', 'KPL4']
                },
                xAxis: [{
                    name: '时间',
                    type: 'category',
                    axisLabel: {
                        rotate: 20
                    },
                    data: (function() {
                        var now = new Date();
                        var res = [];
                        var len = 6;
                        while (len--) {
                            res.unshift(now.toLocaleTimeString().replace(/^\D*/, ''));
                            now = new Date(now - 5000);
                        }
                        return res;
                    })()
                }],
                yAxis: [{
                    name: '焊接电流（A）',
                    type: 'value',
                    min: 10,
                    max: 120,
                }],
                series: [{
                        name: 'KPL1',
                        type: 'line',
                        data: (function() {
                            var res = [];
                            var len = 6;
                            while (len--) {
                                res.push(Math.round(Math.random() * 40 * 2) + 20);
                            }
                            return res;
                        })()

                    },
                    {
                        name: 'KPL2',
                        type: 'line',
                        data: (function() {
                            var res = [];
                            var len = 6;
                            while (len--) {
                                res.push(Math.round(Math.random() * 40 * 2) + 20);
                            }
                            return res;
                        })(),

                    }, {
                        name: 'KPL3',
                        type: 'line',
                        data: (function() {
                            var res = [];
                            var len = 6;
                            while (len--) {
                                res.push(Math.round(Math.random() * 40 * 2) + 20);
                            }
                            return res;
                        })()
                    },
                    {
                        name: 'KPL4',
                        type: 'line',
                        data: (function() {
                            var res = [];
                            var len = 6;
                            while (len--) {
                                res.push(Math.round(Math.random() * 40 * 2) + 20);
                            }
                            return res;
                        })()
                    },
                ]
            }],
            elemELebar = $('#LAY-index-electricity').children('div');
            renderCurrentbar = function(index) {
            ecurrentbar[index] = echarts.init(elemELebar[index], layui.echartsTheme);
            ecurrentbar[index].setOption(currentbar[index]);
            window.onresize = ecurrentbar[index].resize;
        };
        if (!elemELebar[0]) return;
        renderCurrentbar(0);

        //焊接电压
        var eVoltagebar = [],
            vlotagebar = [{
                tooltip: {
                    trigger: 'axis',
                },
                grid: {
                    x: '15%',
                    x2: '10%'
                },
                legend: {
                    data: ['KPL1', 'KPL2', 'KPL3', 'KPL4']
                },
                calculable: true,
                xAxis: [{
                    name: '时间',
                    type: 'category',
                    axisLabel: {
                        rotate: 20
                    },
                    data: nowTimeArray
                }],
                yAxis: [{
                    name: '   焊接电压（0.1V）',
                    type: 'value'
                }],
                series: [{
                        name: 'KPL1',
                        type: 'line',
                        data: [30, 35, 45, 30, 50, 54]
                    },
                    {
                        name: 'KPL2',
                        type: 'line',
                        data: [34, 50, 40, 45, 60, 35],
                    }, {
                        name: 'KPL3',
                        type: 'line',
                        data: [50, 40, 45, 50, 60, 45],
                    },
                    {
                        name: 'KPL4',
                        type: 'line',
                        data: [50, 60, 55, 65, 40, 50],
                    },
                ]
            }],
            elemVoltagebar = $('#LAY-index-voltage').children('div'),
            renderVoltagebar = function(index) {
                eVoltagebar[index] = echarts.init(elemVoltagebar[index], layui.echartsTheme);
                eVoltagebar[index].setOption(vlotagebar[index]);
                window.onresize = eVoltagebar[index].resize;
            };
        if (!elemVoltagebar[0]) return;
        renderVoltagebar(0);

        //送丝速度
        var espeedbar = [],
            speedbar = [{
                grid: {
                    x: '15%',
                    x2: '10%'
                },
                tooltip: {
                    trigger: 'axis',
                },
                legend: {
                    data: ['KPL1', 'KPL2', 'KPL3', 'KPL4']
                },
                calculable: true,
                xAxis: [{
                    name: '时间',
                    type: 'category',
                    data: nowTimeArray,
                    axisLabel: {
                        rotate: 20
                    },
                }],
                yAxis: [{
                    name: '                    送丝速度（0.1M/min）',
                    type: 'value'
                }],
                series: [{
                        name: 'KPL1',
                        type: 'line',
                        data: [5, 6, 10, 12, 13, 8]
                    },
                    {
                        name: 'KPL2',
                        type: 'line',
                        data: [6, 7, 15, 14, 12, 10],
                    }, {
                        name: 'KPL3',
                        type: 'line',
                        data: [6, 10, 7, 8, 10, 13],
                    },
                    {
                        name: 'KPL4',
                        type: 'line',
                        data: [7, 10, 12, 14, 8, 15],
                    },
                ]
            }],
            elemSpeedbar = $('#LAY-index-speed').children('div');
        espeedbar[0] = echarts.init(elemSpeedbar[0], layui.echartsTheme);
        var renderSpeedbar = function(index) {

            espeedbar[index].setOption(speedbar[index]);
            // window.onresize = espeedbar[index].resize;
        };
        if (!elemSpeedbar[0]) return;
        renderSpeedbar(0);

        // 动态数据
        setInterval(function() {

            axisData = (new Date()).toLocaleTimeString().replace(/^\D*/, '');
            // 动态时间

            nowTimeArray.push(getNowTime(0));
            nowTimeArray.shift();
            // 焊接电流
            var current1 = currentbar[0].series[0].data;
            var current2 = currentbar[0].series[1].data;
            var current3 = currentbar[0].series[2].data;
            var current4 = currentbar[0].series[3].data;


            currentbar[0].xAxis[0].data.push(axisData);
            currentbar[0].xAxis[0].data.shift();
            current1.push(Math.round(Math.random() * 40 * 2) + 20);
            current1.shift();

            current2.push(Math.round(Math.random() * 40 * 2.5) + 20);
            current2.shift();

            current3.push(Math.round(Math.random() * 42 * 2) + 20);
            current3.shift();

            current4.push(Math.round(Math.random() * 40 * 2) + 20);
            current4.shift();
            renderCurrentbar(0);

            // 焊接电压
            var volgate1 = vlotagebar[0].series[0].data;
            var volgate2 = vlotagebar[0].series[1].data;
            var volgate3 = vlotagebar[0].series[2].data;
            var volgate4 = vlotagebar[0].series[3].data;
            volgate1.shift();
            volgate1.push(Math.round(Math.random() * 30) + 30);
            volgate2.shift();
            volgate2.push(Math.round(Math.random() * 30) + 30);
            volgate3.shift();
            volgate3.push(Math.round(Math.random() * 30) + 40);
            volgate4.shift();
            volgate4.push(Math.round(Math.random() * 30) + 40);
            renderVoltagebar(0);

            // 送丝速度
            var speed1 = speedbar[0].series[0].data;
            var speed2 = speedbar[0].series[1].data;
            var speed3 = speedbar[0].series[2].data;
            var speed4 = speedbar[0].series[3].data;
            speed1.shift();
            speed1.push(Math.round(Math.random() * 10) + 5);
            speed2.shift();
            speed2.push(Math.round(Math.random() * 10) + 6);
            speed3.shift();
            speed3.push(Math.round(Math.random() * 10) + 5);
            speed4.shift();
            speed4.push(Math.round(Math.random() * 10) + 6);
            renderSpeedbar(0);

        }, 5000);

    });

    exports('dashboard', {})

});