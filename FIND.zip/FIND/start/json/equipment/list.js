{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "id": "001"
    ,"label": "DEFALUT"
    ,"title": "否"
  },{
    "id": "002"
    ,"label": "类型1"
    ,"title": "分配给客户1"
  },{
    "id": "003"
    ,"label": "类型2"
    ,"title": "舌尖上的中国第三季"
  },{
    "id": "001"
    ,"label": "DEFALUT"
    ,"title": "否"
  },{
    "id": "002"
    ,"label": "类型1"
    ,"title": "分配给客户1"
  },{
    "id": "003"
    ,"label": "类型2"
    ,"title": "舌尖上的中国第三季"
  },{
    "id": "001"
    ,"label": "DEFALUT"
    ,"title": "否"
  },{
    "id": "002"
    ,"label": "类型1"
    ,"title": "分配给客户1"
  },{
    "id": "003"
    ,"label": "类型2"
    ,"title": "舌尖上的中国第三季"
  }]
}