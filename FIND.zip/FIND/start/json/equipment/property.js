{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "id": "2018.9.10 10:10"
    ,"label": "设备属性"
    ,"title": "name"
    ,"value": "111"
  },{
    "id": "2018.9.11 12:10"
    ,"label": "实体属性"
    ,"title": "age"
    ,"value": "11"
  },{
    "id": "2018.9.11 12:10"
    ,"label": "服务器属性"
    ,"title": "sex"
    ,"value": "male"
  },{
    "id": "2018.9.10 10:10"
    ,"label": "设备属性"
    ,"title": "name"
    ,"value": "111"
  },{
    "id": "2018.9.11 12:10"
    ,"label": "实体属性"
    ,"title": "age"
    ,"value": "11"
  },{
    "id": "2018.9.11 12:10"
    ,"label": "服务器属性"
    ,"title": "sex"
    ,"value": "male"
  },{
    "id": "2018.9.10 10:10"
    ,"label": "设备属性"
    ,"title": "name"
    ,"value": "111"
  },{
    "id": "2018.9.11 12:10"
    ,"label": "实体属性"
    ,"title": "age"
    ,"value": "11"
  },{
    "id": "2018.9.11 12:10"
    ,"label": "服务器属性"
    ,"title": "sex"
    ,"value": "male"
  }]
}