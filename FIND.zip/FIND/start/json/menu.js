{
    "code": 200,
    "msg": "eew",
    "data": [{
                "title": "总控",
                "icon": "layui-icon-home",
                "jump": "/"

            },
            {
                "title": "设备中心",
                "icon": "layui-icon-util",
                "jump": "/equipment/"

            },
            {
                "title": "告警管理",
                "icon": "layui-icon-notice",
                "jump": "/2"

            },
            {
                "title": "呈现",
                "icon": "layui-icon-chart",
                "jump": "/dashboard/"

            },
            {
                "title": "日志管理",
                "icon": "layui-icon-date",
                "jump": "/4"

            },
            {
                "title": "用户管理",
                "icon": "layui-icon-user",
                "jump": "/5"

            },
            {
                "title": "售后中心",
                "name":"aftersale",
                "icon": "layui-icon-log",
                "list": [{
                    "name": "maintenancePlan",
                    "title": "维保计划",
                    "jump": "/aftersale/maintenancePlan"
                },{
                    "name": "repairs",
                    "title": "报修管理",
                    "jump": "/aftersale/repairs"
                },{
                    "name": "workOrders",
                    "title": "工单管理",
                    "jump": "/aftersale/workorder"
                },{
                    "name": "myWorkOrders",
                    "title": "我的工单",
                    "jump": "/aftersale/myworkorder"
                }]
            }]
          }