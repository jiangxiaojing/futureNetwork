{
  "code": 200
  ,"msg": ""
  ,"data": {
    "username": "贤心"
    ,"sex": "男"
    ,"role": 1
  }
}