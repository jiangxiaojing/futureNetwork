﻿// 终端
var terminalChart = echarts.init(document.getElementById('country_terminal'));
var terminalOption = {
  grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '5%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
        axisLabel :{
          interval:0,
        },
        data: ['CPE', 'VCPE', '物联网', '工业网关']
    },
    yAxis: {
        type: 'value',
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        }
    },
    series: [{
        data: [120, 200, 150, 80],
        type: 'bar',
        barWidth:'45%',
        itemStyle: {
                color: '#4CF6F9',
            },
    }]
};
terminalChart.setOption(terminalOption);


// 接入方式
var inputChart = echarts.init(document.getElementById('country_input'));
var inputOption = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    series: [{
        name: '接入方式',
        type: 'pie',
        radius: ['55%', '65%'],
        avoidLabelOverlap: false,
        label: {
            normal: {
                show: true,
                position: 'outside',
                color: '#fff'
            },
        },
        labelLine: {
            normal: {
                show: true
            }
        },
        color: [
            '#4ED7fb',
            '#FBDC33',
            '#4CF6F9',
            '#fe8E35'
        ],
        data: [
            { value: 150, name: 'NB' },
            { value: 240, name: '4G' },
            { value: 350, name: '有线专网' },
            { value: 230, name: '有线公网' }
        ]
    }]
};
inputChart.setOption(inputOption);


// 网络
var networkChart = echarts.init(document.getElementById('country_network'));
var networkOption = {
    tooltip: {
        trigger: 'axis'
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '5%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
        boundaryGap: ['10%', '10%'],
        data: ['南京','北京','深圳','合肥','武汉']
    },
    yAxis: {
        type: 'value',
        name: '%',
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
    },
    series: [{
            name: 'CPU',
            type: 'bar',
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: 'rgba(50,189,198,.9)'},
                            {offset: 0.5, color: 'rgba(181,188,196,.9)'},
                            {offset: 1, color: 'rgba(174,189,210,.9)'}
                        ]
                    )
                }
            },
            lineStyle:{
              width:3
            },
            data: [45, 50, 51, 48, 51]
        },
        {
            name: '内存',
            type: 'bar',
            itemStyle: {
                normal: {
                    color:'rgba(231,117,117,.9)'
                }
            },
            lineStyle:{
              width:3
            },
            data: [13, 15, 21, 18, 19]
        },
        {
            name: '网络接口',
            type: 'bar',
            itemStyle: {
                normal: {
                    color:'#4CF6F9'
                }
            },
            // barWidth:'10%',
            barGap:'10%',
            lineStyle:{
              width:3
            },
            data: [12, 56, 45, 75, 24]
        }
    ]
};
networkChart.setOption(networkOption);



// china map
var chinaChart = echarts.init(document.getElementById('country_map'));
const CENI_superMap = {
  南京:[118.832955,31.873953],
  北京:[116.342143,39.986485],
  武汉:[114.419826,30.518754],
  成都:[104.031547,30.61408],
  广州:[113.357136,23.157433],
}
const CENI_ONMap = {
  上海:[121.426605,31.162365],
  合肥:[117.311286,31.808059],
  天津:[117.360151,39.112265],
  重庆:[106.532469,29.593713],
  西安:[109.028519,34.335036],
  长沙:[113.06104,28.236709],
  杭州:[120.247355,30.299019],
  郑州:[113.760983,34.774887],
  哈尔滨:[126.542992,45.829489],
  太原:[112.562323,37.830032],
  济南:[116.889812,36.655668],
  南昌:[115.180568,28.939741],
  福州:[119.146663,26.586769],
  昆明:[102.697232,25.057475],
  银川:[106.28037,38.526725  ],
  贵阳:[106.678654,26.449822],
  南宁:[106.696704,24.616654],
  石家庄:[114.454468,38.035982],
  长春:[125.294525,43.817201],
  苏州:[120.647105,31.296173],
  宁波:[121.623845,29.86888],
  许昌:[113.853342,34.034079],
};
const CENI_OFFMap = {
  乌鲁木齐:[87.565797,43.834509],
  拉萨:[91.095527,29.664101],
  西宁:[101.732129,36.659525],
  兰州:[103.826151,36.089171],
  中卫:[105.172523,37.502036],
  呼和浩特:[111.778509,40.863264],
  张家口:[111.778509,40.863264],
  沈阳:[123.474958,41.703683],
  大连:[121.628527,38.90952],
  青岛:[120.410155,36.082962],
  厦门:[118.105634,24.451729],
  深圳:[114.158263,22.596512],
  珠海:[113.452051,22.225719],
  海口:[110.319777,20.029922],
};
const lab_Map = {
	长三角:[118.864635,32.07182],
	珠三角:[121.45481,37.4648],
	胶东半岛:[114.078925,22.583699],
  四川:[104.09416,30.659591],
  京津冀:[116.772709,39.542891]
};
const CENI_Map = {
  南京:[118.832955,31.873953],
  北京:[116.342143,39.986485],
  上海:[121.426605,31.162365],
  合肥:[117.311286,31.808059],
  广州:[113.357136,23.157433],
  天津:[117.360151,39.112265],
  重庆:[106.532469,29.593713],
  西安:[109.028519,34.335036],
  武汉:[114.419826,30.518754],
  成都:[104.031547,30.61408],
  长沙:[113.06104,28.236709],
  杭州:[120.247355,30.299019],
  郑州:[113.760983,34.774887],
  哈尔滨:[126.542992,45.829489],
  太原:[112.562323,37.830032],
  济南:[116.889812,36.655668],
  南昌:[115.180568,28.939741],
  福州:[119.146663,26.586769],
  昆明:[102.697232,25.057475],
  银川:[106.28037,38.526725  ],
  贵阳:[106.678654,26.449822],
  南宁:[106.696704,24.616654],
  石家庄:[114.454468,38.035982],
  长春:[125.294525,43.817201],
  苏州:[120.647105,31.296173],
  宁波:[121.623845,29.86888],
  许昌:[113.853342,34.034079],
  乌鲁木齐:[87.565797,43.834509],
  拉萨:[91.095527,29.664101],
  西宁:[101.732129,36.659525],
  兰州:[103.826151,36.089171],
  中卫:[105.172523,37.502036],
  呼和浩特:[111.778509,40.863264],
  张家口:[111.778509,40.863264],
  沈阳:[123.474958,41.703683],
  大连:[121.628527,38.90952],
  青岛:[120.410155,36.082962],
  厦门:[118.105634,24.451729],
  深圳:[114.158263,22.596512],
  珠海:[113.452051,22.225719],
  海口:[110.319777,20.029922],
}

const data = [
{name: '乌鲁木齐',value: 10},
{name: '拉萨',value: 10},
{name: '西宁',value: 10},
{name: '兰州',value: 10},
{name: '中卫',value: 10},
{name: '呼和浩特',value: 10},
{name: '张家口',value: 10},
{name: '沈阳',value: 10},
{name: '大连',value: 10},
{name: '青岛',value: 10},
{name: '厦门',value: 10},
{name: '深圳',value: 10},
{name: '珠海',value: 10},
{name: '海口',value: 10},
{name: '南京',value: 10},
{name: '北京',value: 10},
{name: '上海',value: 10},
{name: '合肥',value: 10},
{name: '广州',value: 10},
{name: '天津',value: 10},
{name: '重庆',value: 10},
{name: '西安',value: 10},
{name: '武汉',value: 10},
{name: '成都',value: 10},
{name: '长沙',value: 10},
{name: '杭州',value: 10},
{name: '郑州',value: 10},
{name: '哈尔滨',value: 10},
{name: '太原',value: 10},
{name: '济南',value: 10},
{name: '南昌',value: 10},
{name: '福州',value: 10},
{name: '昆明',value: 10},
{name: '银川',value: 10},
{name: '贵阳',value: 10},
{name: '南宁',value: 10},
{name: '石家庄',value: 10},
{name: '长春',value: 10},
{name: '苏州',value: 10},
{name: '宁波',value: 10},
{name: '长三角',value: 10},
{name: '珠三角',value: 10},
{name: '胶东半岛',value: 10},
{name: '四川',value: 10},
{name: '京津冀',value: 10},
];

function LinesData() {
  const tGeoDt = [];
  tGeoDt.push({coords: [CENI_Map['乌鲁木齐'], CENI_Map['兰州']]});
  tGeoDt.push({coords: [CENI_Map['西宁'], CENI_Map['兰州']]});
  tGeoDt.push({coords: [CENI_Map['西宁'], CENI_Map['拉萨']]});
  tGeoDt.push({coords: [CENI_Map['兰州'], CENI_Map['中卫']]});
  tGeoDt.push({coords: [CENI_Map['银川'], CENI_Map['中卫']]});
  tGeoDt.push({coords: [CENI_Map['银川'], CENI_Map['呼和浩特']]});
  tGeoDt.push({coords: [CENI_Map['银川'], CENI_Map['太原']]});
  tGeoDt.push({coords: [CENI_Map['西安'], CENI_Map['银川']]});
  tGeoDt.push({coords: [CENI_Map['太原'], CENI_Map['西安']]});
  tGeoDt.push({coords: [CENI_Map['张家口'], CENI_Map['呼和浩特']]});
  tGeoDt.push({coords: [CENI_Map['张家口'], CENI_Map['哈尔滨']]});
  tGeoDt.push({coords: [CENI_Map['长春'], CENI_Map['哈尔滨']]});
  tGeoDt.push({coords: [CENI_Map['长春'], CENI_Map['沈阳']]});
  tGeoDt.push({coords: [CENI_Map['大连'], CENI_Map['沈阳']]});
  tGeoDt.push({coords: [CENI_Map['北京'], CENI_Map['沈阳']]});
  tGeoDt.push({coords: [CENI_Map['北京'], CENI_Map['天津']]});
  tGeoDt.push({coords: [CENI_Map['北京'], CENI_Map['石家庄']]});
  tGeoDt.push({coords: [CENI_Map['天津'], CENI_Map['济南']]});
  tGeoDt.push({coords: [CENI_Map['石家庄'], CENI_Map['太原']]});
  tGeoDt.push({coords: [CENI_Map['石家庄'], CENI_Map['郑州']]});
  tGeoDt.push({coords: [CENI_Map['西安'], CENI_Map['郑州']]});
  tGeoDt.push({coords: [CENI_Map['济南'], CENI_Map['郑州']]});
  tGeoDt.push({coords: [CENI_Map['济南'], CENI_Map['青岛']]});
  tGeoDt.push({coords: [CENI_Map['济南'], CENI_Map['苏州']]});
  tGeoDt.push({coords: [CENI_Map['青岛'], CENI_Map['上海']]});
  tGeoDt.push({coords: [CENI_Map['苏州'], CENI_Map['上海']]});
  tGeoDt.push({coords: [CENI_Map['杭州'], CENI_Map['上海']]});
  tGeoDt.push({coords: [CENI_Map['杭州'], CENI_Map['宁波']]});
  tGeoDt.push({coords: [CENI_Map['南京'], CENI_Map['合肥']]});
  tGeoDt.push({coords: [CENI_Map['南京'], CENI_Map['苏州']]});
  tGeoDt.push({coords: [CENI_Map['合肥'], CENI_Map['武汉']]});
  tGeoDt.push({coords: [CENI_Map['郑州'], CENI_Map['武汉']]});
  tGeoDt.push({coords: [CENI_Map['郑州'], CENI_Map['重庆']]});
  tGeoDt.push({coords: [CENI_Map['成都'], CENI_Map['重庆']]});
  tGeoDt.push({coords: [CENI_Map['成都'], CENI_Map['昆明']]});
  tGeoDt.push({coords: [CENI_Map['贵阳'], CENI_Map['昆明']]});
  tGeoDt.push({coords: [CENI_Map['贵阳'], CENI_Map['重庆']]});
  tGeoDt.push({coords: [CENI_Map['贵阳'], CENI_Map['长沙']]});
  tGeoDt.push({coords: [CENI_Map['武汉'], CENI_Map['长沙']]});
  tGeoDt.push({coords: [CENI_Map['南昌'], CENI_Map['长沙']]});
  tGeoDt.push({coords: [CENI_Map['南昌'], CENI_Map['福州']]});
  tGeoDt.push({coords: [CENI_Map['宁波'], CENI_Map['福州']]});
  tGeoDt.push({coords: [CENI_Map['厦门'], CENI_Map['福州']]});
  tGeoDt.push({coords: [CENI_Map['厦门'], CENI_Map['深圳']]});
  tGeoDt.push({coords: [CENI_Map['广州'], CENI_Map['深圳']]});
  tGeoDt.push({coords: [CENI_Map['广州'], CENI_Map['长沙']]});
  tGeoDt.push({coords: [CENI_Map['广州'], CENI_Map['珠海']]});
  tGeoDt.push({coords: [CENI_Map['深圳'], CENI_Map['珠海']]});
  tGeoDt.push({coords: [CENI_Map['海口'], CENI_Map['珠海']]});
  tGeoDt.push({coords: [CENI_Map['海口'], CENI_Map['南宁']]});
  tGeoDt.push({coords: [CENI_Map['昆明'], CENI_Map['南宁']]});
  return tGeoDt;
}

function CENIData(data,MapData) {
  var res = [];
  for (var i = 0; i < data.length; i++) {
    var geoCoord = MapData[data[i].name];
    if (geoCoord) {
      res.push({
        name: data[i].name,
        value: geoCoord.concat(data[i].value)
      });
    }
  }
  return res;
};


var chinaOption = {
    tooltip: {
        show: true
        // formatter: function(params) {
        //   console.log(params);
        //   return params.name + ':<br/>' +
        //     '新建POP点数量：' + params.value;
        // }
    },
grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: 0,
        containLabel: true
    },
    legend: {
        orient: 'vertical',
        bottom: '5%',
        left: 0,
        data: ['超核节点', '19年建成', '20年建成','区域网络', '链路'],
        textStyle: {
            color: '#fff'
        }
    },
    geo: {
        name: 'Enroll distribution',
        type: 'map',
        map: 'china',
        zoom:1.2,
        top:'20%',
        roam: true,
        label: {
            // show: true,
            color: '#345165'
        },
        emphasis: {
            label: {
                color: '#fff'
            }
        },
        itemStyle: {
            normal: {
                areaColor: '#56bad1',
                borderColor: '#FFF',
                shadowColor: 'rgba(15, 116, 186, 0.5)',
                shadowBlur: 10,
                shadowOffsetX:-10
            },
            emphasis: {
                areaColor: '#2a333d',
            }
        }
    },
    series: [{
        name: '超核节点',
        type: 'effectScatter',
        coordinateSystem: 'geo',
        symbol: 'circle',
        symbolSize: 8,
        zlevel: 2,
        label: {
            show: false,
            formatter: '{b}',
            position: 'bottom',
            color: '#fff',
            fontSize: '11'
        },
        tooltip: {
            formatter: '{b}'
        },
        itemStyle: {
            normal: {
                color: '#fee453'
            },
        },
        data: CENIData(data, CENI_superMap),
    },{
        name: '19年建成',
        type: 'scatter',
        coordinateSystem: 'geo',
        zlevel: 2,
        symbol: 'circle',
        symbolSize: 8,
        label: {
            show: false,
            formatter: '{b}',
            position: 'bottom',
            color: '#fff',
            fontSize: '11'
        },
        tooltip: {
            formatter: '{b}'
        },
        itemStyle: {
            normal: {
                color: '#fe8e35'
            },
        },
        data: CENIData(data, CENI_ONMap),
    }, {
        name: '20年建成',
        type: 'scatter',
        zlevel: 2,
        coordinateSystem: 'geo',
        symbol: 'circle',
        symbolSize: 8,
        label: {
            show: false,
            formatter: '{b}',
            position: 'bottom',
            color: '#fff',
            fontSize: '11'
        },
        tooltip: {
            formatter: '{b}'
        },
        itemStyle: {
            normal: {
                color: '#fff'
            },
        },
        data: CENIData(data, CENI_OFFMap),
    }, {
        name: '区域网络',
        type: 'scatter',
        zlevel: 1,
        coordinateSystem: 'geo',
        symbol: 'circle',
        symbolSize: 35,
        label: {
            show: false,
            formatter: '{b}',
            position: 'bottom',
            color: '#fff',
            fontSize: '11'
        },
        tooltip: {
            formatter: '{b}'
        },
        itemStyle: {
            normal: {
                color: 'rgba(221,48,96,.7)'
            },
        },
        data: CENIData(data, lab_Map),
    },{
    	name:'链路',
      type: 'lines',
      zlevel: 2,
      effect:{
        symbol:'circle',
        show:true,
	symbolSize:5
      },
      lineStyle: {
        normal: {
          color: '#fff',
          width: 1,
          opacity: 1,
        },
      },
      data: LinesData(),
    }]
};
chinaChart.setOption(chinaOption);

// 动态网络
setInterval(function (){
    var datacpu = networkOption.series[0].data;
    var datamemory = networkOption.series[1].data;
    var datainterface = networkOption.series[2].data;
    console.log(datacpu,datainterface);
    datacpu.shift();
    datacpu.push(Math.round(Math.random() * 10)+45);
    datamemory.shift();
    datamemory.push(Math.round(Math.random() * 10)+15);
    datainterface.shift();
    datainterface.push(Math.round(Math.random() * 10)+10);
    networkChart.setOption(networkOption);
}, 5000);

// 动态丢包率
setInterval(function (){
  var lost1  = document.getElementById('lost1');
  var lost2  = document.getElementById('lost2');
  var lost3  = document.getElementById('lost3');
  var lost4  = document.getElementById('lost4');
  var lost5  = document.getElementById('lost5');
  var lost6  = document.getElementById('lost6');

  lost1.innerHTML = (Math.random()*0.4).toFixed(2)+"%";
  lost2.innerHTML = (Math.random()*0.4).toFixed(2)+"%";
  lost3.innerHTML = (Math.random()*0.4).toFixed(2)+"%";
  lost4.innerHTML = (Math.random()*0.4).toFixed(2)+"%";
  lost5.innerHTML = (Math.random()*0.4).toFixed(2)+"%";
  lost6.innerHTML = (Math.random()*0.4).toFixed(2)+"%";
}, 2000);
