﻿// POP节点分类
var inputChart = echarts.init(document.getElementById('province_categories'));
var inputOption = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    series: [{
        name: '节点分类',
        type: 'pie',
        radius: ['70%', '80%'],
        avoidLabelOverlap: false,
        label: {
            normal: {
                show: true,
                position: 'outside',
                color: '#fff'
            },
        },
        labelLine: {
            normal: {
                show: true
            }
        },
        color: [
            '#4ED7fb',
            '#FBDC33',
            '#4CF6F9',
            '#fe8E35'
        ],
        data: [
            { value: 150, name: '建设中' },
            { value: 240, name: '已完成' }
        ]
    }]
};
inputChart.setOption(inputOption);


// OCO利用率
var networkChart = echarts.init(document.getElementById('country_network'));
var networkOption = {
    tooltip: {
        trigger: 'axis'
    },
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '5%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
        axisLabel: {
            rotate: 0,
            interval: 0
        },
        boundaryGap: ['10%', '10%'],
        data: ['苏州', '徐州', '南京1', '南京2']
    },
    yAxis: {
        type: 'value',
        name: '%',
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
    },
    series: [{
            name: 'CPU',
            type: 'bar',
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1, [
                            { offset: 0, color: 'rgba(50,189,198,.9)' },
                            { offset: 0.5, color: 'rgba(181,188,196,.9)' },
                            { offset: 1, color: 'rgba(174,189,210,.9)' }
                        ]
                    )
                }
            },
            lineStyle: {
                width: 3
            },
            data: [45, 50, 51, 48]
        },
        {
            name: '内存',
            type: 'bar',
            itemStyle: {
                normal: {
                    color: 'rgba(231,117,117,.9)'
                }
            },
            lineStyle: {
                width: 3
            },
            data: [13, 15, 21, 18]
        },
        {
            name: '网络接口',
            type: 'bar',
            itemStyle: {
                normal: {
                    color: '#4CF6F9'
                }
            },
            // barWidth:'10%',
            barGap: '10%',
            lineStyle: {
                width: 3
            },
            data: [12, 56, 45, 75]
        }
    ]
};
networkChart.setOption(networkOption);


// 企业客户
var tenantChart = echarts.init(document.getElementById('country_tenant'));
var tenantOption = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    series: [{
        name: '企业客户',
        type: 'pie',
        radius: ['60%', '70%'],
        avoidLabelOverlap: false,
        label: {
            normal: {
                show: true,
                position: 'outside',
                color: '#fff'
            },
        },
        labelLine: {
            normal: {
                show: true
            }
        },
        color: [
            '#4ED7fb',
            '#FBDC33',
            '#4CF6F9',
            '#fe8E35'
        ],
        data: [
            { value: 150, name: '智能制造' },
            { value: 100, name: '电子信息' },
            { value: 140, name: '智能装备' },
            { value: 50, name: '生物医药' },
            { value: 30, name: '纺织' },
            { value: 40, name: '食品' },
        ]
    }]
};
tenantChart.setOption(tenantOption);

// 工业互联网类型
var typeChart = echarts.init(document.getElementById('province_type'));
var typeOption = {
    tooltip: {
        trigger: 'item',
        formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    grid: {
        top: 0
    },
    series: [{
        name: '工业互联网类型',
        type: 'pie',
        radius: ['50%', '60%'],
        avoidLabelOverlap: false,
        label: {
            normal: {
                show: true,
                position: 'outside',
                color: '#fff'
            },
        },
        labelLine: {
            normal: {
                show: true
            }
        },
        color: [
            '#4ED7fb',
            '#FBDC33',
            '#4CF6F9',
            '#fe8E35'
        ],
        data: [
            { value: 150, name: '单分支' },
            { value: 100, name: '多分支' },
            { value: 140, name: '蜂窝回传' }
        ]
    }]
};
typeChart.setOption(typeOption);



// 江苏地图
var provinceChart = echarts.init(document.getElementById('province_map'));
const geoPOPMap = {
    苏州点: [120.619926, 31.112294],
    未来网络: [118.833817, 31.873564],
    无锡点: [120.336776, 31.69227],
    徐州点: [117.207837, 34.226382],
};
const geoCloudMap = {
    南京pop节点: [118.778701, 32.473004],
    常州pop节点: [120.029717, 31.909783],
    苏州pop节点: [120.739696, 31.776681],
    南通pop节点: [121.244816, 32.323588],
};
const geoDataMap = {
    宿迁数据中心: [118.015213, 34.057153],
    扬州数据中心: [119.321421, 32.636612],
    南京数据中心: [119.008667, 31.461414],
    南通数据中心: [120.544841, 32.215298]
};
const provinceData = [{
        name: '苏州点',
        value: 10,
    }, {
        name: '未来网络',
        value: 45,
    }, {
        name: '无锡点',
        value: 14,
    }, {
        name: '徐州点',
        value: 10,
    }, {
        name: '盐城点',
        value: 6,
    },
    {
        name: '镇江点',
        value: 6,
    }, {
        name: '南京pop节点',
        value: 6,
    }, {
        name: '常州pop节点',
        value: 6,
    }, {
        name: '苏州pop节点',
        value: 6,
    }, {
        name: '宿迁数据中心',
        value: 6,
    }, {
        name: '扬州数据中心',
        value: 6,
    }, {
        name: '南京数据中心',
        value: 6,
    }, {
        name: '南通数据中心',
        value: 6,
    }, {
        name: '南通pop节点',
        value: 10
    }
];

function LinesData() {
    const tGeoDt = [];
    tGeoDt.push({ coords: [geoPOPMap['未来网络'], geoPOPMap['苏州点']] });
    tGeoDt.push({ coords: [geoPOPMap['未来网络'], geoPOPMap['无锡点']] });
    tGeoDt.push({ coords: [geoPOPMap['未来网络'], geoPOPMap['徐州点']] });
    tGeoDt.push({ coords: [geoPOPMap['无锡点'], geoPOPMap['徐州点']] });
    tGeoDt.push({ coords: [geoPOPMap['无锡点'], geoPOPMap['苏州点']] });
    return tGeoDt;
}
function whiteLinesData() {
    const tGeoDt = [];
    tGeoDt.push({ coords: [geoCloudMap['南京pop节点'], geoCloudMap['常州pop节点']] });
    tGeoDt.push({ coords: [geoCloudMap['南京pop节点'], geoCloudMap['南通pop节点']] });
    tGeoDt.push({ coords: [geoCloudMap['常州pop节点'], geoCloudMap['苏州pop节点']] });
    tGeoDt.push({ coords: [geoCloudMap['常州pop节点'], geoCloudMap['南通pop节点']] });
    tGeoDt.push({ coords: [geoCloudMap['苏州pop节点'], geoCloudMap['南通pop节点']] });
    tGeoDt.push({ coords: [geoPOPMap['未来网络'], geoCloudMap['南京pop节点']] });
    tGeoDt.push({ coords: [geoPOPMap['未来网络'], geoCloudMap['常州pop节点']] });
    tGeoDt.push({ coords: [geoPOPMap['苏州点'], geoCloudMap['苏州pop节点']] });
    return tGeoDt;
}

function convertData(data, MapData) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord = MapData[data[i].name];
        if (geoCoord) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].value)
            });
        }
    }
    return res;
};

var provinceOption = {
    tooltip: {
        show: true
        // formatter: function(params) {
        //   console.log(params);
        //   return params.name + ':<br/>' +
        //     '新建POP点数量：' + params.value;
        // }
    },
    legend: {
        orient: 'vertical',
        bottom: '10%',
        left: 0,
        data: ['已建成POP点', '建设中POP点', '边缘云'],
        textStyle: {
            color: '#fff'
        }
    },
    geo: {
        name: 'Enroll distribution',
        type: 'map',
        map: '江苏',
        zoom: 1.2,
        roam: true,
        label: {
            show: true,
            color: '#ddd'
        },
        emphasis: {
            label: {
                color: '#fff'
            }
        },
        itemStyle: {
            normal: {
                areaColor: '#56bad1',
                borderColor: '#FFF',
                shadowColor: 'rgba(15, 116, 186, 0.5)',
                shadowBlur: 10,
                shadowOffsetX: -10
            },
            emphasis: {
                areaColor: '#2a333d',
            }
        }
    },
    series: [{
            name: '已建成POP点',
            type: 'effectScatter',
            coordinateSystem: 'geo',
            symbol: 'circle',
            symbolSize: 12,
            zlevel: 2,
            label: {
                normal: {
                    formatter: '{a}',
                    position: 'right',
                    show: false
                },
            },
            tooltip: {
                formatter: '{b}'
            },
            itemStyle: {
                normal: {
                    color: '#ddc007'
                },
            },
            data: convertData(provinceData, geoPOPMap),
        },
        {
            name: '建设中POP点',
            type: 'scatter',
            coordinateSystem: 'geo',
            symbol: 'circle',
            zlevel: 2,
            symbolSize: 10,
            label: {
                normal: {
                    formatter: '{a}',
                    position: 'right',
                    show: false
                },
            },
            tooltip: {
                formatter: '{b}'
            },
            itemStyle: {
                normal: {
                    color: '#fff'
                },
            },
            data: convertData(provinceData, geoCloudMap),
        },
        {
            name: '边缘云',
            type: 'scatter',
            coordinateSystem: 'geo',
            symbol: 'circle',
            symbolSize: 8,
            label: {
                normal: {
                    formatter: '{a}',
                    position: 'right',
                    show: false
                },
            },
            tooltip: {
                formatter: '{b}'
            },
            itemStyle: {
                normal: {
                    color: '#b9452a'
                },
            },
            data: convertData(provinceData, geoDataMap),
        }, {
            name: '链路',
            type: 'lines',
            zlevel: 2,
            effect: {
                symbol: 'circle',
                show: true,
                symbolSize: 5
            },
            lineStyle: {
                normal: {
                    color: '#ddc007',
                    width: 2,
                    opacity: 0.8,
                },
            },
            data: LinesData(),
        }, {
            name: '链路',
            type: 'lines',
            effect: {
                symbol: 'circle',
                show: true,
                symbolSize: 5
            },
            lineStyle: {
                normal: {
                    color: '#fff',
                    width: 2,
                    opacity: 0.8,
                },
            },
            data: whiteLinesData(),
        }
    ]
};
provinceChart.setOption(provinceOption);


// 动态网络
setInterval(function() {
    var datacpu = networkOption.series[0].data;
    var datamemory = networkOption.series[1].data;
    var datainterface = networkOption.series[2].data;
    datacpu.shift();
    datacpu.push(Math.round(Math.random() * 10) + 45);
    datamemory.shift();
    datamemory.push(Math.round(Math.random() * 10) + 15);
    datainterface.shift();
    datainterface.push(Math.round(Math.random() * 10) + 10);
    networkChart.setOption(networkOption);
}, 5000);

// 动态带宽利用率
setInterval(function() {
    var bandwidth1 = document.getElementById('bandwidth1');
    var bandwidth2 = document.getElementById('bandwidth2');
    var bandwidth3 = document.getElementById('bandwidth3');
    var bandwidth4 = document.getElementById('bandwidth4');
    var bandwidth5 = document.getElementById('bandwidth5');
    var bandwidth6 = document.getElementById('bandwidth6');

    bandwidth1.innerHTML = parseFloat(((Math.random() * 20) - 10 + 20)).toFixed(1) + "%";
    bandwidth2.innerHTML = parseFloat(((Math.random() * 20) - 10 + 15)).toFixed(1) + "%";
    bandwidth3.innerHTML = parseFloat(((Math.random() * 20) - 10 + 12)).toFixed(1) + "%";
    bandwidth4.innerHTML = parseFloat(((Math.random() * 20) - 10 + 70)).toFixed(1) + "%";
    bandwidth5.innerHTML = parseFloat(((Math.random() * 20) - 10 + 25)).toFixed(1) + "%";
    bandwidth6.innerHTML = parseFloat(((Math.random() * 20) - 10 + 50)).toFixed(1) + "%";
}, 2000);