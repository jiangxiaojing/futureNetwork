// 世界地图
var worldChart = echarts.init(document.getElementById('world_map'));
const geoCoordMap = {
    波士顿: [-82.131, 35.742],
    西雅图: [-117.7358570000, 45.841],
    东京: [139.653866, 35.748846],
    新加坡: [103.886858, 1.37796],
    香港: [114.224931, 22.266831],
    缅甸: [97.969116, 20.380419],
    悉尼: [143.204131, -30.845746],
    法兰克福: [8.703399, 50.130144],
    伦敦: [0.08119, 51.514165],
    南京: [118.819564, 32.055677],
    苏州: [120.674701, 31.278645],
    徐州: [117.356166, 34.255747]
};

const CENI_ONMap = {
    南京: [118.832955, 31.873953],
    北京: [116.342143, 39.986485],
    广州: [113.357136, 23.157433],
    武汉: [114.419826, 30.518754],
    成都: [106.696704, 24.616654]
};

const proMap = {
    geni: [-89.131, 40.742],
    OneLab: [15.081191, 56.130144],
    CENI: [120.081191, 45.130144],
}

const data = [{
        name: '波士顿',
        value: 1,
    },
    {
        name: '西雅图',
        value: 1,
    },
    {
        name: 'geni',
        value: 1,
    },
    {
        name: 'OneLab',
        value: 1,
    },
    {
        name: 'CENI',
        value: 1,
    },
    {
        name: '东京',
        value: 1,
    },
    {
        name: '新加坡',
        value: 1,
    },
    {
        name: '香港',
        value: 1,
    },
    {
        name: '缅甸',
        value: 1,
    },
    {
        name: '悉尼',
        value: 1,
    },
    {
        name: '法兰克福',
        value: 1,
    },
    {
        name: '伦敦',
        value: 1,
    },
    {
        name: '南京',
        value: 1,
    },
    {
        name: '苏州',
        value: 1,
    },
    {
        name: '无锡',
        value: 1,
    }, { name: '南京', value: 10 },
    { name: '北京', value: 10 },
    { name: '广州', value: 10 },
    { name: '武汉', value: 10 },
    { name: '成都', value: 10 },
];

function LinesDataArrow(LineData) {
    const tGeoDt = [];
    tGeoDt.push({ coords: [geoCoordMap['东京'], geoCoordMap['香港']] });
    tGeoDt.push({ coords: [geoCoordMap['波士顿'], geoCoordMap['西雅图']] });
    tGeoDt.push({ coords: [geoCoordMap['西雅图'], geoCoordMap['伦敦']] });
    tGeoDt.push({ coords: [geoCoordMap['新加坡'], geoCoordMap['伦敦']] });
    tGeoDt.push({ coords: [geoCoordMap['香港'], geoCoordMap['波士顿']] });
    tGeoDt.push({ coords: [geoCoordMap['悉尼'], geoCoordMap['伦敦']] });
    tGeoDt.push({ coords: [geoCoordMap['法兰克福'], geoCoordMap['东京']] });
    tGeoDt.push({ coords: [geoCoordMap['香港'], geoCoordMap['悉尼']] });
    tGeoDt.push({ coords: [geoCoordMap['缅甸'], geoCoordMap['东京']] });
    tGeoDt.push({ coords: [geoCoordMap['伦敦'], geoCoordMap['波士顿']] });
    tGeoDt.push({ coords: [geoCoordMap['东京'], geoCoordMap['西雅图']] });
    tGeoDt.push({ coords: [geoCoordMap['法兰克福'], geoCoordMap['缅甸']] });
    tGeoDt.push({ coords: [geoCoordMap['南京'], geoCoordMap['苏州']] });
    tGeoDt.push({ coords: [geoCoordMap['苏州'], geoCoordMap['波士顿']] });
    return tGeoDt;
}

function LinesDataNone(LineData) {
    const tGeoDt = [];
    tGeoDt.push({ coords: [proMap['geni'], proMap['OneLab']] });
    tGeoDt.push({ coords: [proMap['CENI'], proMap['geni']] });
    tGeoDt.push({ coords: [proMap['OneLab'], proMap['CENI']] });
    return tGeoDt;
}

function LinesDataCENI() {
    const tGeoDt = [];
    tGeoDt.push({ coords: [CENI_ONMap['北京'], CENI_ONMap['广州']] });
    tGeoDt.push({ coords: [CENI_ONMap['北京'], CENI_ONMap['南京']] });
    tGeoDt.push({ coords: [CENI_ONMap['南京'], CENI_ONMap['武汉']] });
    tGeoDt.push({ coords: [CENI_ONMap['成都'], CENI_ONMap['武汉']] });
    return tGeoDt;
}

function ScatterData(Data, MapData) {
    const tGeoDt = [];
    for (let i = 0, len = Data.length; i < len; i++) {
        const tNam = Data[i].name;
        tGeoDt.push({
            name: tNam,
            value: MapData[tNam],
            symbolSize: 4,
            itemStyle: {
                normal: {
                    color: '#fee453',
                    borderColor: 'gold',
                },
            },
        });
    }
    return tGeoDt;
}

function CENI_ON(data, MapData) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord = MapData[data[i].name];
        if (geoCoord) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].value)
            });
        }
    }
    return res;
};

function StaticScatterData(Data, MapData) {
    const tGeoDt = [];
    for (let i = 0, len = Data.length; i < len; i++) {
        const tNam = Data[i].name;
        tGeoDt.push({
            name: tNam,
            value: MapData[tNam],
            symbolSize: 20,
            symbol: 'pin',
            itemStyle: {
                normal: {
                    color: 'rgb(241, 84, 35)',
                    borderColor: 'rgb(241, 84, 35)',
                },
            },
        });
    }
    return tGeoDt;
}

// var planePath = 'path://M1705.06,1318.313v-89.254l-319.9-221.799l0.073-208.063c0.521-84.662-26.629-121.796-63.961-121.491c-37.332-0.305-64.482,36.829-63.961,121.491l0.073,208.063l-319.9,221.799v89.254l330.343-157.288l12.238,241.308l-134.449,92.931l0.531,42.034l175.125-42.917l175.125,42.917l0.531-42.034l-134.449-92.931l12.238-241.308L1705.06,1318.313z';
const planePath = 'arrow';

var worldOption = {
    grid: {
        left: '3%',
        right: '4%',
        bottom: 0,
        top: '5%',
        containLabel: true
    },
    geo: {
        name: 'Enroll distribution',
        type: 'map',
        map: 'world',
        zoom: 1.3,
        roam: true,
        aspectScale:0.6,
        label: {
            emphasis: {
                show: false,
            },
        },
        itemStyle: {
            normal: {
                areaColor: '#56bad1',
                borderColor: '#FFF',
                shadowColor: 'rgba(15, 116, 186, 0.5)',
                shadowBlur: 10,
                shadowOffsetX: -10
            },
            emphasis: {
                areaColor: '#2a333d',
            }
        }
    },
    series: [{
            type: 'lines',
            zlevel: 1,
            effect: {
                show: true,
                period: 6,
                trailLength: 0.1,
                color: '#FFB973',
                symbol: 'arrow',
                symbolSize: 5,
            },
            lineStyle: {
                normal: {
                    color: '#FFB973',
                    width: 1,
                    opacity: 0.2,
                    curveness: 0.2,
                },
            },
            data: LinesDataArrow(data),
        }, {
            type: 'lines',
            zlevel: 1,
            effect: {
                show: true,
                period: 6,
                trailLength: 0.1,
                color: 'rgb(241, 84, 35)',
                symbol: 'rect',
                symbolSize: 10,
            },
            lineStyle: {
                normal: {
                    color: 'rgb(241, 84, 35)',
                    width: 3,
                    opacity: 1,
                },
            },
            data: LinesDataNone(data),
        },
        {
            type: 'lines',
            zlevel: 1,
            lineStyle: {
                normal: {
                    color: '#fff',
                    width: 1,
                    opacity: 1,
                },
            },
            data: LinesDataCENI(),
        },
        {
            type: 'effectScatter',
            coordinateSystem: 'geo',
            zlevel: 2,
            rippleEffect: {
                period: 4,
                scale: 4,
                brushType: 'stroke',
            },
            label: {
                normal: {
                    show: true,
                    position: 'right',
                    formatter: '{b}',
                },
            },
            symbolSize: 5,
            data: ScatterData(data, geoCoordMap),
        },
        {
            type: 'scatter',
            coordinateSystem: 'geo',
            legendHoverLink: 'true',
            zlevel: 2,
            symbol: 'rect',
            symbolSize: 20,
            label: {
                normal: {
                    show: true,
                    position: 'top',
                    formatter: '{b}',
                    fontSize: 14,
                    color: 'rgb(241, 84, 35)'
                },
            },
            itemStyle: {
                normal: {
                    color: 'blue',
                    shadowBlur: 10,
                    shadowColor: '#333'
                }
            },
            data: StaticScatterData(data, proMap),
        }, {
            name: 'CENI已实施',
            type: 'scatter',
            coordinateSystem: 'geo',
            symbol: 'circle',
            symbolSize: 8,
            label: {
                normal: {
                    formatter: '{a}',
                    position: 'right',
                    show: false
                },
            },
            tooltip: {
                formatter: '{b}'
            },
            itemStyle: {
                normal: {
                    color: '#fe8e35'
                },
            },
            data: CENI_ON(data, CENI_ONMap),
        }
    ],
};
worldChart.setOption(worldOption);


// type1
// var type1Chart = echarts.init(document.getElementById('world_type1'));
// var type1Option = {
//     tooltip: {
//         show: false
//     },
//     series: [{
//         name: '接入方式',
//         type: 'pie',
//         radius: ['60%', '70%'],
//         avoidLabelOverlap: false,
//         label: {
//             normal: {
//                 show: true,
//                 position: 'outside',
//                 color: '#fff'
//             },
//         },
//         labelLine: {
//             normal: {
//                 show: true
//             }
//         },
//         color: [
//             '#4ED7fb',
//             '#FBDC33',
//             '#23B69C',
//             '#fe8E35'
//         ],
//         data: [
//             { value: 150, name: 'NB' },
//             { value: 240, name: '4G' },
//             { value: 350, name: '有线专网' },
//             { value: 230, name: '有线公网' }
//         ]
//     }]
// };
// type1Chart.setOption(type1Option);

// type2
var type2Chart = echarts.init(document.getElementById('world_type2'));
var type2Option = {
    tooltip: {
        show: false
    },
    series: [{
        name: 'SDWAN节点分布',
        type: 'pie',
        radius: ['60%', '70%'],
        avoidLabelOverlap: false,
        label: {
            normal: {
                show: true,
                position: 'outside',
                color: '#fff'
            },
        },
        labelLine: {
            normal: {
                show: true
            }
        },
        color: [
            '#4ED7fb',
            '#FBDC33',
            '#23B69C',
            '#fe8E35'
        ],
        data: [
            { value: 5, name: '亚洲' },
            { value: 3, name: '欧洲' },
            { value: 1, name: '大洋洲' },
            { value: 2, name: '美洲' },
        ]
    }]
};
type2Chart.setOption(type2Option);

// type3
var type3Chart = echarts.init(document.getElementById('world_type3'));
var type3Option = {
    tooltip: {
        show: false
    },
    series: [{
        name: '实验成果',
        type: 'pie',
        radius: ['60%', '70%'],
        avoidLabelOverlap: false,
        tooltip: {
            show: false
        },
        label: {
            normal: {
                show: true,
                position: 'outside',
                color: '#fff'
            },
        },
        labelLine: {
            normal: {
                show: true
            }
        },
        color: [
            '#4ED7fb',
            '#FBDC33',
            '#23B69C',
            '#fe8E35'
        ],
        data: [
            { value: 150, name: '论文数' },
            { value: 240, name: '重点实验' },
            { value: 240, name: '顶会期刊' }
        ]
    }]
};
type3Chart.setOption(type3Option);

// 节点分布情况
var nodeChart = echarts.init(document.getElementById('world_node'));
var nodeOption = option = {
    grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        top: '5%',
        containLabel: true
    },
    tooltip: {
        show: false
    },
    calculable: true,
    xAxis: [{
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
        type: 'category',
        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月']
    }],
    yAxis: [{
        axisLine: {
            lineStyle: {
                color: '#fff'
            }
        },
        type: 'value'
    }],
    series: [{
            name: '蒸发量',
            type: 'bar',
            zlevel:1,
            barGap:'-30%',
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(
                        0, 0, 0, 1,
                        [
                            {offset: 0, color: 'rgba(50,189,198,.8)'},
                            {offset: 0.5, color: 'rgba(181,188,196,.8)'},
                            {offset: 1, color: 'rgba(174,189,210,.8)'}
                        ]
                    )
                }
            },
            data: [10,23,14,23,10,8,13,14,18,10],
        },
        {
            name: '降水量',
            type: 'bar',
            itemStyle: {
                normal: {
                    color:'rgba(32,75,102,.8)'
                }
            },
            data: [12,23,14,15,8,23,21,21,18,14],
        }
    ]
};
nodeChart.setOption(nodeOption);